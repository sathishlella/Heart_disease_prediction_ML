#__________________________________________________________________IMPORT_MODULES_____________________________________________________________________________________
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#_____________________________________________________________________DATA_ACCESS_____________________________________________________________________________________
path=r"C:\Users\TOSHIBA-PC\Desktop\New folder\heart_attack_prediction.csv"
#path="Add Data path here.."
names=["male","age","education","current_smoker","cigsperday","bpmeds","prevalentscor","prevalentHyp","diabetets","totchol","sysbp","diaBP","bmi","heartrate","glucose","tenyearchd"]
data=pd.read_csv(path,names=names)
print(data.shape)
x=data.iloc[:,:15].values
y=data.iloc[:,15].values
"""
#___________________________________________________________________DATA_PREPROCESSING___________________________________________________________________________________
Data processing is done manualy because some of the values in the data set are not avaliable .so they are replaced with some average values,
so that our accuracy may not fall much!  
"""

#____________________________________________________________________CORRELATONS______________________________________________________________________________________

correlations=data.corr()
print(correlations)
#________________________________________________________________CORRELATION_PLOTTING________________________________________________________________________________
fig=plt.figure()
ax=fig.add_subplot(111)
cax=ax.matshow(correlations,vmax=1,vmin=-1)
fig.colorbar(cax)
ticks=np.arange(0,9,1)
ax.set_xticks(ticks)
ax.set_yticks(ticks)
ax.set_xticklabels(names)
ax.set_yticklabels(names)
plt.show()
#__________________________________________________________________HISTOGRAM_PLOTTING________________________________________________________________________________
data.hist()
plt.show()
#________________________________________________________________SCATTER_MATRIX_PLOTTING_______________________________________________________________________________
from pandas.plotting import scatter_matrix
scatter_matrix(data)
plt.show()

#______________________________________________________________________DATA_TRAINING____________________________________________________________________________________
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.312,random_state=1)
"""
We have done normalization and standardization but haven't got any differences in accurarcies .So we have removed these..
#_______________________________________________________________________NORMALIZATION_____________________________________________________________________________________
from sklearn.preprocessing import Normalizer
scaler=Normalizer().fit(x)
rescaledx=scaler.transform(x)
#print(rescaledx)

#______________________________________________________________________STANDARDIZATION________________________________________________________________________________
from sklearn import preprocessing
names=data.columns
scaler=preprocessing.StandardScaler()
scaled_data=scaler.fit_transform(data)
scaled_data=pd.DataFrame(scaled_data,columns=names)
"""
#_______________________________________________________________________KNN____________________________________________________________________________________________
#Got an accuracy of  84.05139833
from sklearn.neighbors import KNeighborsClassifier
model_knn=KNeighborsClassifier(n_neighbors=3)
model_knn.fit(x_train,y_train) 
y_pred=model_knn.predict(x_test)
from sklearn.metrics import accuracy_score
print("acciuracy KNN:",accuracy_score(y_test,y_pred)*100)

#_______________________________________________________________________NAIVE_BAYES____________________________________________________________________________________
#Got an accuracy of 82.9176115
from sklearn.naive_bayes import GaussianNB
model_nb=GaussianNB()
model_nb.fit(x_train,y_train)
y_pred=model_nb.predict(x_test)
print("accuracy NAIVE:",accuracy_score(y_test,y_pred)*100)
#_______________________________________________________________________DECISION_TREE________________________________________________________________________________
#Got an accuracy of 75.58578987150416
from sklearn import tree
model_DT=tree.DecisionTreeClassifier(criterion="entropy")
model_DT=model_DT.fit(x_train,y_train)
y_pred=model_DT.predict(x_test)
#print(y_pred)
print("acciuracy DEC_TREE:",accuracy_score(y_test,y_pred)*100)


#________________________________________________________________RANDOM_FOREST__________________________________________________________________________________________
#Among all these three random forest techniques the highest accuracy of 86.77248677248677

from sklearn.ensemble import RandomForestClassifier
model5=RandomForestClassifier(n_estimators=200)                          
model5.fit(x_train,y_train)
y_pred_random_forest=model5.predict(x_test)
print("Random_forest accuracy:",accuracy_score(y_test,y_pred_random_forest)*100)
modelrand=RandomForestClassifier(max_depth=5,min_samples_split=3,min_samples_leaf=1)
modelrand.fit(x_train,y_train)
y_pred_random_forest=modelrand.predict(x_test)
print("Random_forest accuracy_leaf:",accuracy_score(y_test,y_pred_random_forest)*100)
modelrand1=RandomForestClassifier(max_features=10)
modelrand1=RandomForestClassifier(max_features=.3)
modelrand1.fit(x_train,y_train)
y_pred_random_forest=modelrand1.predict(x_test)
print("Random_forest accuracy_features:",accuracy_score(y_test,y_pred_random_forest)*100)

#_______________________________________________________________________SVM_________________________________________________________________________________________________________
#Gave an accuracy of 86.9992441421019
from sklearn.svm import SVC
model_svm=SVC()
model_svm.fit(x_train,y_train)
y_pred_svm=model_svm.predict(x_test)
print("svm accuracy:",accuracy_score(y_test,y_pred_svm)*100)

#______________________________________________________________________LOGISTIC_REGRESSION_____________________________________________________________________________
#This algorithm gave the maximum accuracy!!
#The maximum accuracy we got is ...    87.07482993197279
#So  by using LOGISTIC_REGRESSION we got better results...
from sklearn.linear_model import LogisticRegression
model_LOGI=LogisticRegression()
model_LOGI.fit(x_train,y_train)
y_pred=model_LOGI.predict(x_test)
from sklearn.metrics import accuracy_score
print("acciuracy LOGISTIC:",accuracy_score(y_test,y_pred)*100)

#New test data
y_pred=model_LOGI.predict([[0,61,3,1,30,1,0,1,1,225,150,95,28.58,65,103]])
print(y_pred)
#we got future prediction is 0(no chances of heart disease) with LogisticRegression. 
